package com.example.configservcie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigServcieApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigServcieApplication.class, args);
	}

}
